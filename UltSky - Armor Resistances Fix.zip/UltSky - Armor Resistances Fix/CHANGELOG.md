# Table of Contents

<!-- TOC -->

- [v1.1.1](#v111)
- [v1.1.0](#v110)
- [v1.0.1](#v101)
- [v1.0.0](#v100)

<!-- /TOC -->

# v1.1.1
> 2021-02-12

- Renamed to `UltSky` from `US`

# v1.1.0
>2021-02-12

- Added resistance values to Ahzidal's Armor of Retribution.
- Added a changelog.


# v1.0.1 
>2021-02-09

- Added resistances to Stalhrim Heavy Cuirass because I forgot to.

# v1.0.0 
>2021-02-09

- Initial release.