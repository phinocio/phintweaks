# Table of Contents

<!-- TOC -->

- [v1.0.1](#v101)
- [v1.0.0](#v100)

<!-- /TOC -->

# v1.0.1
>2021-02-12

- Remove `PhinTweaks` from .esp name.
- Rename folders/files to be in-line with proper name/capitalization of `Wet and Cold`.

# v1.0.0
>2020-05-21

- Initial release.